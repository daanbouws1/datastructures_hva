package opdracht2;

import Algorithms.BucketSort;
import Algorithms.InsertionSort;
import java.util.ArrayList;
import java.util.List;

import models.Student;
import nl.hva.dmci.ict.se.datastructures.util.Generator;
import nl.hva.dmci.ict.se.datastructures.util.Stopwatch;

/**
 *
 * @author Daan
 */
public class Opdracht2 {

    private static final int AANSTAL_STUDENTEN = 16000;
    private static ArrayList<Student> students = new ArrayList<>();
    private static InsertionSort sort;
    private static Stopwatch timer = new Stopwatch();
    private static Generator gen = new Generator(AANSTAL_STUDENTEN);

    public static void main(String[] args) {
        students = gen.generateStudents();

//        for (Student student: students) {
//            System.out.println(student);
//        }

        insertionSort();
        bucketSort();
    }

    private static void insertionSort() {
        timer.startStopwatch();
        sort = new InsertionSort();
        sort.insertionSort(students);

        timer.stopStopwatch();
//        System.out.println(isStijgend(students));
        System.out.println(timer.getTime());
    }

    private static void bucketSort() {
        timer.startStopwatch();

        ArrayList<ArrayList<Student>> sorteerdeStudenten = BucketSort.sort(students);

        System.out.println(isStijgend(students));

        for (ArrayList<Student> bucket : sorteerdeStudenten) {
//            System.out.println(bucket);
            for (Student student : bucket) {
//                System.out.println(student);
            }
        }
        System.out.println(timer.getTime());
    }

    //werrukt nie
    public static <T extends Comparable<T>> boolean isStijgend(List<T> rij) {
        boolean result = false;
        return rij.get(0).compareTo(rij.get(1)) < 0 ? (rij.size() <= 2 ? result = true : isStijgend(rij.subList(1, rij.size()))) : result;
    }
}
